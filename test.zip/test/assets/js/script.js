$('.single-block').slick({
    prevArrow: '<button id="prev" type="button" class="btn btn-juliet"><img src="assets/img/previous.png" alt=""></button>',
    nextArrow: '<button id="next" type="button" class="btn btn-juliet"><img src="assets/img/next.png" alt=""></button>'
});